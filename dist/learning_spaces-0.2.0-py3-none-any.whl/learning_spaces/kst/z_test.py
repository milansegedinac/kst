import numpy as np

def z_test():

    return {}