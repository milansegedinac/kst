import numpy as np


def variance():

    return {}