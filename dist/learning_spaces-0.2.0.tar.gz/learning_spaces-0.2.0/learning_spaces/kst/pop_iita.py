import numpy as np


def pop_iita():

    return {}