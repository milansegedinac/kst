import numpy as np
import pandas as pd

def state2imp(P):

    return {}